var url_base = "http://localhost:8080/";
var usuario = undefined;
var listaStatus = undefined;
var statusSelecionado=undefined;
var listaTabela=undefined;

function login(event){
    event.preventDefault();
    var login = $('#email').val();
    var senha = $('#senha').val();

    var dados={};
    
    if(login.includes('@'))
        dados.email = login;
    else
        dados.racf = login;

    dados.senha = senha;

    $.ajax({
        url: url_base+"usuario/login",
        contentType: "application/json",
        method:"POST",
        data: JSON.stringify(dados),
        success: function(data){
            usuario=data;
            $('#container').load('./dashboard.html', function(){
                $('#fotoUsuario').attr('src',usuario.caminhoFoto);
                $('#nome').text(usuario.nome + " ("+usuario.racf+")");
                popularComboFiltro();
            });
        },
        error:function(erro){
            alert("Usuário e senha inválidos!");
        }
    });
}

function logout(event){
    event.preventDefault();
    usuario = undefined;
    listaStatus = undefined;
    statusSelecionado=undefined;
    listaTabela=undefined;
    window.location.href="./Index.html";
}

function popularComboFiltro(){
    $.ajax({
        url: url_base+"status",
        method:"GET",
        success: function(data){
            listaStatus = data;
            var options = '<option value="all">Todos</option>';
            listaStatus.forEach(function(item){
                options+='<option value="'+item.id+'">'+item.nome+'</option>';
            });
            $('#status').append(options);
            popularTabela();
        },
        error:function(erro){
            alert("Erro ao carregar Status!");
        }
    });
}

function popularTabela(){
    var statusSelecionado = $('#status').find('option:selected').val();

    $.ajax({
        url: url_base+"solicitacoes"+((statusSelecionado=="all")? '':'?status='+statusSelecionado),
        method:"GET",
        success: function(data){
            listaTabela = data;
            preencherTabela();
        },
        error:function(erro,ok,status){
            if(erro.status!=404) alert("Erro ao carregar solicitacoes!");
            else {
                listaTabela=undefined;
                preencherTabela();
            }
        }
    });

}

function preencherTabela(){
    var trs = '';
    if(listaTabela!=undefined){
        listaTabela.forEach(function(item){
            trs+="<tr>"
                + "<td scope='col'>"+item.nomeTecnico+"</td>"
                + "<td scope='col'>"+item.operadora+"</td>"
                + "<td scope='col'>"+item.telefone+"</td>"
                + "<td scope='col'>"+item.documento+"</td>"
                + "<td scope='col'>"+item.pdv.nome+"</td>"
                + "<td scope='col'>"+item.data+"</td>"
                + "<td scope='col'>"+item.hora+"</td>"
                + "<td scope='col'>"+item.status.nome+"</td>"
                + "<td scope='col'>"+
                    '<button type="submit" class="btn btn-success" onclick="alterarStatus(event,'+item.numeroSequencia+',2)"></button>'+
                    '<button type="submit" class="btn btn-warning" onclick="alterarStatus(event,'+item.numeroSequencia+',3)"></button>'+
                    '<button type="submit" class="btn btn-danger" onclick="alterarStatus(event,'+item.numeroSequencia+',4)"></button>'
                +"</td></tr>";
        });
    }
    $('#tableBody').html(trs);
}

function alterarStatus(event, id, statusId){
    event.preventDefault();
    var solicitacao = undefined;
    listaTabela.forEach(function(item){
        if(item.numeroSequencia==id)
            solicitacao = item;
    });

    if(solicitacao!=undefined){
        solicitacao.status = { id: statusId };
        $.ajax({
            url: url_base+"solicitacao/"+solicitacao.numeroSequencia,
            method:"PUT",
            contentType: "application/json",
            data: JSON.stringify(solicitacao),
            success: function(data){
                popularTabela();
            },
            error:function(erro){
                alert("Erro ao alterar Status!");
            }
        });
    }
}

function filtrar(event){
    event.preventDefault();
    popularTabela();
}

function carregarPdvs(){
    $.ajax({
        url: url_base+"pdvs",
        method:"GET",
        success: function(data){
            listaStatus = data;
            var options = '';
            listaStatus.forEach(function(item){
                options+='<option value="'+item.id+'">'+item.nome+'</option>';
            });
            $('#pdv').append(options);
        },
        error:function(erro){
            alert("Erro ao carregar Pdvs!");
        }
    });
}

function cadastrar(event){
    event.preventDefault();
    var solicitacao={};

    solicitacao.nomeTecnico=$('#nome').val().trim();
    solicitacao.operadora=$('#operadora').val().trim();
    solicitacao.telefone=$('#telefone').val().trim();
    solicitacao.documento=$('#documento').val().trim();
    var date = $('#data').val().trim();
    date = date.replace(/\//g,'-');
    solicitacao.data=date;
    solicitacao.hora=$('#hora').val().trim();
    solicitacao.pdv={id:$('#pdv').find('option:selected').val()};
    solicitacao.status={id:1};

    $.ajax({
        url: url_base+"solicitacao",
        contentType: "application/json",
        method:"POST",
        data: JSON.stringify(solicitacao),
        success: function(data){
            alert("Solicitação cadastrada com sucesso!");
            window.location.href="./cadastro.html";
        },
        error:function(erro){
            alert("Erro ao cadastrar solicitação!");
        }
    });
}